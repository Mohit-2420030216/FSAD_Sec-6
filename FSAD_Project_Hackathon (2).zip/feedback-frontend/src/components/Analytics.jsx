import { useState, useEffect } from 'react';
import api from '../services/api';

function Analytics() {
  const [analytics, setAnalytics] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAnalytics = async () => {
      try {
        const res = await api.getAnalytics();
        setAnalytics(res.data);
      } catch (err) {
        console.error('Error fetching analytics:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchAnalytics();
  }, []);

  if (loading) {
    return (
      <div className="page-container">
        <div className="loading">
          <div className="spinner"></div>
          Loading analytics...
        </div>
      </div>
    );
  }

  if (!analytics) {
    return (
      <div className="page-container">
        <div className="empty-state">
          <div className="empty-icon">📊</div>
          <h3>No analytics data</h3>
          <p>Add some feedbacks to see analytics.</p>
        </div>
      </div>
    );
  }

  const { overallAverageRating, averageRatingByProduct, feedbackCountByProduct, ratingDistribution, totalFeedbacks } = analytics;

  const maxDistCount = Math.max(...Object.values(ratingDistribution || {}), 1);

  return (
    <div className="page-container">
      <div className="page-header">
        <h1>Analytics Dashboard</h1>
        <p>Insights and averages from all customer feedback</p>
      </div>

      {/* Summary Stats */}
      <div className="analytics-grid">
        <div className="stat-card">
          <div className="stat-label">Total Feedbacks</div>
          <div className="stat-value">{totalFeedbacks}</div>
          <div className="stat-sub">All submissions to date</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Overall Average Rating</div>
          <div className="stat-value">{overallAverageRating?.toFixed(1) || '0.0'}</div>
          <div className="stat-sub">
            <span className="stars" style={{ fontSize: '1rem' }}>
              {[1, 2, 3, 4, 5].map((s) => (
                <span key={s} className={`star ${s <= Math.round(overallAverageRating || 0) ? 'filled' : ''}`}>★</span>
              ))}
            </span>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Products Reviewed</div>
          <div className="stat-value">{Object.keys(averageRatingByProduct || {}).length}</div>
          <div className="stat-sub">Unique products with feedback</div>
        </div>
      </div>

      {/* Rating Distribution */}
      <div className="section-header">
        <h2>⭐ Rating Distribution</h2>
      </div>
      <div className="card" style={{ marginBottom: '2rem' }}>
        <div className="rating-bar-container">
          {[5, 4, 3, 2, 1].map((rating) => {
            const count = ratingDistribution?.[rating] || ratingDistribution?.[String(rating)] || 0;
            const pct = maxDistCount > 0 ? (count / maxDistCount) * 100 : 0;
            return (
              <div className="rating-bar" key={rating}>
                <span className="bar-label">{'★'.repeat(rating)} {rating}</span>
                <div className="bar-track">
                  <div className="bar-fill" style={{ width: `${pct}%` }}></div>
                </div>
                <span className="bar-count">{count}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Average Rating by Product */}
      <div className="section-header">
        <h2>📦 Average Rating by Product</h2>
      </div>
      <div className="product-grid">
        {Object.entries(averageRatingByProduct || {}).map(([product, avg]) => (
          <div className="product-card" key={product}>
            <div className="product-name">{product}</div>
            <div className="product-avg">{avg.toFixed(1)}</div>
            <div style={{ margin: '4px 0' }}>
              <span className="stars">
                {[1, 2, 3, 4, 5].map((s) => (
                  <span key={s} className={`star ${s <= Math.round(avg) ? 'filled' : ''}`}>★</span>
                ))}
              </span>
            </div>
            <div className="product-count">
              {feedbackCountByProduct?.[product] || 0} review{(feedbackCountByProduct?.[product] || 0) !== 1 ? 's' : ''}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Analytics;
