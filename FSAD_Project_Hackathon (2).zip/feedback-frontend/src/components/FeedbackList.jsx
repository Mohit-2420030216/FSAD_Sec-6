import { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import api from '../services/api';

function FeedbackList() {
  const [feedbacks, setFeedbacks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(0);
  const [totalPages, setTotalPages] = useState(0);
  const [totalItems, setTotalItems] = useState(0);
  const [sortBy, setSortBy] = useState('createdAt');
  const [sortDir, setSortDir] = useState('desc');
  const [productFilter, setProductFilter] = useState('');
  const [ratingFilter, setRatingFilter] = useState('');
  const [products, setProducts] = useState([]);
  const [toast, setToast] = useState(null);
  const pageSize = 8;

  const fetchFeedbacks = useCallback(async () => {
    setLoading(true);
    try {
      const params = {
        page: currentPage,
        size: pageSize,
        sortBy,
        sortDir,
      };
      if (productFilter) params.product = productFilter;
      if (ratingFilter) params.rating = parseInt(ratingFilter);

      const res = await api.getFeedbacks(params);
      setFeedbacks(res.data.feedbacks);
      setTotalPages(res.data.totalPages);
      setTotalItems(res.data.totalItems);
    } catch (err) {
      console.error('Error fetching feedbacks:', err);
    } finally {
      setLoading(false);
    }
  }, [currentPage, sortBy, sortDir, productFilter, ratingFilter]);

  const fetchProducts = async () => {
    try {
      const res = await api.getProducts();
      setProducts(res.data);
    } catch (err) {
      console.error('Error fetching products:', err);
    }
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  useEffect(() => {
    fetchFeedbacks();
  }, [fetchFeedbacks]);

  const handleSort = (field) => {
    if (sortBy === field) {
      setSortDir(sortDir === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(field);
      setSortDir('asc');
    }
    setCurrentPage(0);
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this feedback?')) return;
    try {
      await api.deleteFeedback(id);
      showToast('Feedback deleted successfully', 'success');
      fetchFeedbacks();
      fetchProducts();
    } catch (err) {
      showToast('Failed to delete feedback', 'error');
    }
  };

  const showToast = (message, type) => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  };

  const handleFilterChange = () => {
    setCurrentPage(0);
  };

  const renderStars = (rating) => {
    return (
      <span className="stars">
        {[1, 2, 3, 4, 5].map((star) => (
          <span key={star} className={`star ${star <= rating ? 'filled' : ''}`}>
            ★
          </span>
        ))}
      </span>
    );
  };

  const getSortIcon = (field) => {
    if (sortBy !== field) return '↕';
    return sortDir === 'asc' ? '↑' : '↓';
  };

  const renderPagination = () => {
    if (totalPages <= 1) return null;

    const pages = [];
    const maxVisible = 5;
    let start = Math.max(0, currentPage - Math.floor(maxVisible / 2));
    let end = Math.min(totalPages, start + maxVisible);
    if (end - start < maxVisible) {
      start = Math.max(0, end - maxVisible);
    }

    for (let i = start; i < end; i++) {
      pages.push(i);
    }

    return (
      <div className="pagination">
        <span className="pagination-info">
          Showing {currentPage * pageSize + 1}–{Math.min((currentPage + 1) * pageSize, totalItems)} of {totalItems}
        </span>
        <button
          onClick={() => setCurrentPage(0)}
          disabled={currentPage === 0}
        >
          ««
        </button>
        <button
          onClick={() => setCurrentPage(currentPage - 1)}
          disabled={currentPage === 0}
        >
          «
        </button>
        {pages.map((p) => (
          <button
            key={p}
            className={p === currentPage ? 'active' : ''}
            onClick={() => setCurrentPage(p)}
          >
            {p + 1}
          </button>
        ))}
        <button
          onClick={() => setCurrentPage(currentPage + 1)}
          disabled={currentPage >= totalPages - 1}
        >
          »
        </button>
        <button
          onClick={() => setCurrentPage(totalPages - 1)}
          disabled={currentPage >= totalPages - 1}
        >
          »»
        </button>
      </div>
    );
  };

  return (
    <div className="page-container">
      <div className="page-header">
        <h1>Customer Feedbacks</h1>
        <p>Manage and review all customer feedback submissions</p>
      </div>

      {/* Filter Bar */}
      <div className="filter-bar">
        <select
          value={productFilter}
          onChange={(e) => {
            setProductFilter(e.target.value);
            handleFilterChange();
          }}
          id="product-filter"
        >
          <option value="">All Products</option>
          {products.map((p) => (
            <option key={p} value={p}>{p}</option>
          ))}
        </select>
        <select
          value={ratingFilter}
          onChange={(e) => {
            setRatingFilter(e.target.value);
            handleFilterChange();
          }}
          id="rating-filter"
        >
          <option value="">All Ratings</option>
          {[5, 4, 3, 2, 1].map((r) => (
            <option key={r} value={r}>{'★'.repeat(r)} ({r})</option>
          ))}
        </select>
        <Link to="/add" className="btn btn-primary" style={{ marginLeft: 'auto' }}>
          + Add Feedback
        </Link>
      </div>

      {/* Table */}
      {loading ? (
        <div className="loading">
          <div className="spinner"></div>
          Loading feedbacks...
        </div>
      ) : feedbacks.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">📭</div>
          <h3>No feedbacks found</h3>
          <p>Try adjusting your filters or add a new feedback.</p>
        </div>
      ) : (
        <>
          <div className="table-wrapper">
            <table className="feedback-table">
              <thead>
                <tr>
                  <th
                    className={sortBy === 'customerName' ? 'sorted' : ''}
                    onClick={() => handleSort('customerName')}
                  >
                    Customer
                    <span className="sort-icon">{getSortIcon('customerName')}</span>
                  </th>
                  <th
                    className={sortBy === 'product' ? 'sorted' : ''}
                    onClick={() => handleSort('product')}
                  >
                    Product
                    <span className="sort-icon">{getSortIcon('product')}</span>
                  </th>
                  <th
                    className={sortBy === 'rating' ? 'sorted' : ''}
                    onClick={() => handleSort('rating')}
                  >
                    Rating
                    <span className="sort-icon">{getSortIcon('rating')}</span>
                  </th>
                  <th>Comments</th>
                  <th
                    className={sortBy === 'createdAt' ? 'sorted' : ''}
                    onClick={() => handleSort('createdAt')}
                  >
                    Date
                    <span className="sort-icon">{getSortIcon('createdAt')}</span>
                  </th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {feedbacks.map((fb) => (
                  <tr key={fb.id}>
                    <td><strong>{fb.customerName}</strong></td>
                    <td>{fb.product}</td>
                    <td>{renderStars(fb.rating)}</td>
                    <td style={{ maxWidth: '250px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      {fb.comments || '—'}
                    </td>
                    <td style={{ whiteSpace: 'nowrap', fontSize: '0.8rem', color: 'var(--text-secondary)' }}>
                      {fb.createdAt ? new Date(fb.createdAt).toLocaleDateString('en-US', {
                        year: 'numeric', month: 'short', day: 'numeric'
                      }) : '—'}
                    </td>
                    <td>
                      <div className="table-actions">
                        <Link to={`/edit/${fb.id}`} className="btn btn-secondary btn-sm">
                          ✏️ Edit
                        </Link>
                        <button
                          className="btn btn-danger btn-sm"
                          onClick={() => handleDelete(fb.id)}
                        >
                          🗑️
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {renderPagination()}
        </>
      )}

      {/* Toast */}
      {toast && (
        <div className={`toast ${toast.type}`}>
          {toast.message}
        </div>
      )}
    </div>
  );
}

export default FeedbackList;
