import { Link, useLocation } from 'react-router-dom';

function Navbar() {
  const location = useLocation();

  const isActive = (path) => {
    if (path === '/') return location.pathname === '/';
    return location.pathname.startsWith(path);
  };

  return (
    <nav className="navbar">
      <div className="navbar-inner">
        <Link to="/" className="navbar-brand">
          <span className="logo-icon">💬</span>
          FeedbackHub
        </Link>
        <div className="navbar-links">
          <Link to="/" className={isActive('/') ? 'active' : ''}>
            Feedbacks
          </Link>
          <Link to="/add" className={isActive('/add') ? 'active' : ''}>
            Add New
          </Link>
          <Link to="/analytics" className={isActive('/analytics') ? 'active' : ''}>
            Analytics
          </Link>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;
