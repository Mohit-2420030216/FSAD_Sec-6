import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import api from '../services/api';

function FeedbackForm() {
  const { id } = useParams();
  const navigate = useNavigate();
  const isEdit = Boolean(id);

  const [formData, setFormData] = useState({
    customerName: '',
    product: '',
    rating: 0,
    comments: '',
  });

  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [toast, setToast] = useState(null);

  useEffect(() => {
    if (isEdit) {
      setLoading(true);
      api.getFeedback(id)
        .then((res) => {
          const fb = res.data;
          setFormData({
            customerName: fb.customerName || '',
            product: fb.product || '',
            rating: fb.rating || 0,
            comments: fb.comments || '',
          });
        })
        .catch((err) => {
          showToast('Failed to load feedback', 'error');
          console.error(err);
        })
        .finally(() => setLoading(false));
    }
  }, [id, isEdit]);

  const validate = () => {
    const newErrors = {};
    if (!formData.customerName.trim()) {
      newErrors.customerName = 'Customer name is required';
    } else if (formData.customerName.trim().length < 2) {
      newErrors.customerName = 'Must be at least 2 characters';
    }

    if (!formData.product.trim()) {
      newErrors.product = 'Product name is required';
    } else if (formData.product.trim().length < 2) {
      newErrors.product = 'Must be at least 2 characters';
    }

    if (!formData.rating || formData.rating < 1 || formData.rating > 5) {
      newErrors.rating = 'Please select a rating (1–5)';
    }

    if (formData.comments.length > 500) {
      newErrors.comments = 'Comments must be at most 500 characters';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;

    setSubmitting(true);
    try {
      if (isEdit) {
        await api.updateFeedback(id, formData);
        showToast('Feedback updated successfully!', 'success');
      } else {
        await api.createFeedback(formData);
        showToast('Feedback created successfully!', 'success');
      }
      setTimeout(() => navigate('/'), 1000);
    } catch (err) {
      if (err.response?.data?.errors) {
        setErrors(err.response.data.errors);
      } else {
        showToast('Something went wrong. Please try again.', 'error');
      }
    } finally {
      setSubmitting(false);
    }
  };

  const showToast = (message, type) => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  };

  const handleChange = (field, value) => {
    setFormData({ ...formData, [field]: value });
    if (errors[field]) {
      setErrors({ ...errors, [field]: '' });
    }
  };

  if (loading) {
    return (
      <div className="page-container">
        <div className="loading">
          <div className="spinner"></div>
          Loading feedback...
        </div>
      </div>
    );
  }

  return (
    <div className="page-container">
      <div className="form-container">
        <div className="page-header" style={{ textAlign: 'center' }}>
          <h1>{isEdit ? 'Edit Feedback' : 'Add New Feedback'}</h1>
          <p>{isEdit ? 'Update the feedback details below' : 'Submit a new customer feedback'}</p>
        </div>

        <div className="form-card">
          <form onSubmit={handleSubmit} noValidate>
            {/* Customer Name */}
            <div className="form-group">
              <label htmlFor="customerName">Customer Name *</label>
              <input
                type="text"
                id="customerName"
                placeholder="Enter customer name"
                value={formData.customerName}
                onChange={(e) => handleChange('customerName', e.target.value)}
                className={errors.customerName ? 'error' : ''}
              />
              {errors.customerName && <div className="error-text">{errors.customerName}</div>}
            </div>

            {/* Product */}
            <div className="form-group">
              <label htmlFor="product">Product *</label>
              <input
                type="text"
                id="product"
                placeholder="Enter product name"
                value={formData.product}
                onChange={(e) => handleChange('product', e.target.value)}
                className={errors.product ? 'error' : ''}
              />
              {errors.product && <div className="error-text">{errors.product}</div>}
            </div>

            {/* Rating */}
            <div className="form-group">
              <label>Rating *</label>
              <div className="star-input">
                {[1, 2, 3, 4, 5].map((star) => (
                  <span
                    key={star}
                    className={`star ${star <= formData.rating ? 'filled' : ''}`}
                    onClick={() => handleChange('rating', star)}
                    role="button"
                    tabIndex={0}
                    aria-label={`Rate ${star} star${star > 1 ? 's' : ''}`}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' || e.key === ' ') handleChange('rating', star);
                    }}
                  >
                    ★
                  </span>
                ))}
              </div>
              {errors.rating && <div className="error-text">{errors.rating}</div>}
            </div>

            {/* Comments */}
            <div className="form-group">
              <label htmlFor="comments">Comments</label>
              <textarea
                id="comments"
                placeholder="Share your experience (optional)"
                value={formData.comments}
                onChange={(e) => handleChange('comments', e.target.value)}
                className={errors.comments ? 'error' : ''}
                rows={4}
              />
              <div style={{ textAlign: 'right', fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px' }}>
                {formData.comments.length}/500
              </div>
              {errors.comments && <div className="error-text">{errors.comments}</div>}
            </div>

            {/* Actions */}
            <div className="form-actions">
              <button type="submit" className="btn btn-primary" disabled={submitting} style={{ flex: 1 }}>
                {submitting ? 'Saving...' : isEdit ? '💾 Update Feedback' : '✨ Submit Feedback'}
              </button>
              <button type="button" className="btn btn-secondary" onClick={() => navigate('/')}>
                Cancel
              </button>
            </div>
          </form>
        </div>
      </div>

      {/* Toast */}
      {toast && (
        <div className={`toast ${toast.type}`}>
          {toast.message}
        </div>
      )}
    </div>
  );
}

export default FeedbackForm;
