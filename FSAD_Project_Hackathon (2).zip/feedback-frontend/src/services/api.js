import axios from 'axios';

const API_BASE = '/api/feedbacks';

const api = {
  // Get all feedbacks with pagination, sorting, and filters
  getFeedbacks: (params = {}) => {
    return axios.get(API_BASE, { params });
  },

  // Get single feedback by ID
  getFeedback: (id) => {
    return axios.get(`${API_BASE}/${id}`);
  },

  // Create new feedback
  createFeedback: (data) => {
    return axios.post(API_BASE, data);
  },

  // Update existing feedback
  updateFeedback: (id, data) => {
    return axios.put(`${API_BASE}/${id}`, data);
  },

  // Delete feedback
  deleteFeedback: (id) => {
    return axios.delete(`${API_BASE}/${id}`);
  },

  // Get distinct products
  getProducts: () => {
    return axios.get(`${API_BASE}/products`);
  },

  // Get analytics
  getAnalytics: () => {
    return axios.get(`${API_BASE}/analytics`);
  }
};

export default api;
