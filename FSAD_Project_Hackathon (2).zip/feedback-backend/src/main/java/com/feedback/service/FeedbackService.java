package com.feedback.service;

import com.feedback.exception.ResourceNotFoundException;
import com.feedback.model.Feedback;
import com.feedback.repository.FeedbackRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class FeedbackService {

    @Autowired
    private FeedbackRepository feedbackRepository;

    // Get all feedbacks with pagination, sorting, and optional filters
    public Page<Feedback> getAllFeedbacks(int page, int size, String sortBy, String sortDir,
                                          String product, Integer rating) {
        Sort sort = sortDir.equalsIgnoreCase("desc")
                ? Sort.by(sortBy).descending()
                : Sort.by(sortBy).ascending();

        Pageable pageable = PageRequest.of(page, size, sort);

        if (product != null && !product.isEmpty() && rating != null) {
            return feedbackRepository.findByProductContainingIgnoreCaseAndRating(product, rating, pageable);
        } else if (product != null && !product.isEmpty()) {
            return feedbackRepository.findByProductContainingIgnoreCase(product, pageable);
        } else if (rating != null) {
            return feedbackRepository.findByRating(rating, pageable);
        }

        return feedbackRepository.findAll(pageable);
    }

    // Get feedback by ID
    public Feedback getFeedbackById(Long id) {
        return feedbackRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Feedback", "id", id));
    }

    // Create new feedback
    public Feedback createFeedback(Feedback feedback) {
        return feedbackRepository.save(feedback);
    }

    // Update existing feedback
    public Feedback updateFeedback(Long id, Feedback feedbackDetails) {
        Feedback feedback = getFeedbackById(id);
        feedback.setCustomerName(feedbackDetails.getCustomerName());
        feedback.setProduct(feedbackDetails.getProduct());
        feedback.setRating(feedbackDetails.getRating());
        feedback.setComments(feedbackDetails.getComments());
        return feedbackRepository.save(feedback);
    }

    // Delete feedback
    public void deleteFeedback(Long id) {
        Feedback feedback = getFeedbackById(id);
        feedbackRepository.delete(feedback);
    }

    // Get distinct products for filter dropdown
    public List<String> getDistinctProducts() {
        return feedbackRepository.findDistinctProducts();
    }

    // Get analytics data
    public Map<String, Object> getAnalytics() {
        Map<String, Object> analytics = new HashMap<>();

        // Overall average rating
        Double overallAverage = feedbackRepository.findOverallAverageRating();
        analytics.put("overallAverageRating", overallAverage != null ? Math.round(overallAverage * 100.0) / 100.0 : 0);

        // Average rating per product
        List<Object[]> avgByProduct = feedbackRepository.findAverageRatingByProduct();
        Map<String, Double> productAverages = new HashMap<>();
        for (Object[] row : avgByProduct) {
            productAverages.put((String) row[0], Math.round(((Double) row[1]) * 100.0) / 100.0);
        }
        analytics.put("averageRatingByProduct", productAverages);

        // Feedback count per product
        List<Object[]> countByProduct = feedbackRepository.findFeedbackCountByProduct();
        Map<String, Long> productCounts = new HashMap<>();
        for (Object[] row : countByProduct) {
            productCounts.put((String) row[0], (Long) row[1]);
        }
        analytics.put("feedbackCountByProduct", productCounts);

        // Rating distribution
        List<Object[]> ratingDist = feedbackRepository.findRatingDistribution();
        Map<Integer, Long> distribution = new HashMap<>();
        for (int i = 1; i <= 5; i++) {
            distribution.put(i, 0L);
        }
        for (Object[] row : ratingDist) {
            distribution.put((Integer) row[0], (Long) row[1]);
        }
        analytics.put("ratingDistribution", distribution);

        // Total feedback count
        analytics.put("totalFeedbacks", feedbackRepository.count());

        return analytics;
    }
}
