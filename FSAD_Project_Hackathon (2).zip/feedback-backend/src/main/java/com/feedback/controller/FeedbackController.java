package com.feedback.controller;
import com.feedback.model.Feedback;
import com.feedback.service.FeedbackService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/feedbacks")
public class FeedbackController {

    @Autowired
    private FeedbackService feedbackService;

    // GET
    // /api/feedbacks?page=0&size=10&sortBy=createdAt&sortDir=desc&product=&rating=
    @GetMapping
    public ResponseEntity<Map<String, Object>> getAllFeedbacks(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "createdAt") String sortBy,
            @RequestParam(defaultValue = "desc") String sortDir,
            @RequestParam(required = false) String product,
            @RequestParam(required = false) Integer rating) {

        Page<Feedback> feedbackPage = feedbackService.getAllFeedbacks(page, size, sortBy, sortDir, product, rating);

        Map<String, Object> response = new HashMap<>();
        response.put("feedbacks", feedbackPage.getContent());
        response.put("currentPage", feedbackPage.getNumber());
        response.put("totalItems", feedbackPage.getTotalElements());
        response.put("totalPages", feedbackPage.getTotalPages());

        return ResponseEntity.ok(response);
    }

    // GET /api/feedbacks/{id}
    @GetMapping("/{id}")
    public ResponseEntity<Feedback> getFeedbackById(@PathVariable Long id) {
        Feedback feedback = feedbackService.getFeedbackById(id);
        return ResponseEntity.ok(feedback);
    }

    // POST /api/feedbacks
    @PostMapping
    public ResponseEntity<Feedback> createFeedback(@Valid @RequestBody Feedback feedback) {
        Feedback created = feedbackService.createFeedback(feedback);
        return new ResponseEntity<>(created, HttpStatus.CREATED);
    }

    // PUT /api/feedbacks/{id}
    @PutMapping("/{id}")
    public ResponseEntity<Feedback> updateFeedback(@PathVariable Long id,
            @Valid @RequestBody Feedback feedback) {
        Feedback updated = feedbackService.updateFeedback(id, feedback);
        return ResponseEntity.ok(updated);
    }

    // DELETE /api/feedbacks/{id}
    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String, String>> deleteFeedback(@PathVariable Long id) {
        feedbackService.deleteFeedback(id);
        Map<String, String> response = new HashMap<>();
        response.put("message", "Feedback deleted successfully");
        return ResponseEntity.ok(response);
    }

    // GET /api/feedbacks/products
    @GetMapping("/products")
    public ResponseEntity<List<String>> getDistinctProducts() {
        return ResponseEntity.ok(feedbackService.getDistinctProducts());
    }

    // GET /api/feedbacks/analytics
    @GetMapping("/analytics")
    public ResponseEntity<Map<String, Object>> getAnalytics() {
        return ResponseEntity.ok(feedbackService.getAnalytics());
    }
}
