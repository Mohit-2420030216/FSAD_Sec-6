package com.feedback.repository;

import com.feedback.model.Feedback;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FeedbackRepository extends JpaRepository<Feedback, Long> {

    // Search by product name (case-insensitive partial match)
    Page<Feedback> findByProductContainingIgnoreCase(String product, Pageable pageable);

    // Filter by exact rating
    Page<Feedback> findByRating(Integer rating, Pageable pageable);

    // Filter by product AND rating
    Page<Feedback> findByProductContainingIgnoreCaseAndRating(String product, Integer rating, Pageable pageable);

    // Get distinct product names for filter dropdown
    @Query("SELECT DISTINCT f.product FROM Feedback f ORDER BY f.product")
    List<String> findDistinctProducts();

    // Average rating per product
    @Query("SELECT f.product, AVG(f.rating) FROM Feedback f GROUP BY f.product ORDER BY f.product")
    List<Object[]> findAverageRatingByProduct();

    // Overall average rating
    @Query("SELECT AVG(f.rating) FROM Feedback f")
    Double findOverallAverageRating();

    // Count feedback per product
    @Query("SELECT f.product, COUNT(f) FROM Feedback f GROUP BY f.product ORDER BY f.product")
    List<Object[]> findFeedbackCountByProduct();

    // Rating distribution
    @Query("SELECT f.rating, COUNT(f) FROM Feedback f GROUP BY f.rating ORDER BY f.rating")
    List<Object[]> findRatingDistribution();
}
