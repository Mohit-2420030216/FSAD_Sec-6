package com.feedback.config;

import com.feedback.model.Feedback;
import com.feedback.repository.FeedbackRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;

@Component
public class DataLoader implements CommandLineRunner {

    @Autowired
    private FeedbackRepository feedbackRepository;

    @Override
    public void run(String... args) {
        if (feedbackRepository.count() == 0) {
            List<Feedback> sampleFeedbacks = Arrays.asList(
                new Feedback("Alice Johnson", "Laptop Pro X1", 5, "Absolutely love this laptop! Fast, sleek, and reliable."),
                new Feedback("Bob Smith", "Laptop Pro X1", 4, "Great performance but the battery could be better."),
                new Feedback("Charlie Brown", "Wireless Mouse M200", 3, "Decent mouse, but the scroll wheel feels cheap."),
                new Feedback("Diana Prince", "Wireless Mouse M200", 5, "Perfect ergonomic design, very comfortable for long hours."),
                new Feedback("Edward Norton", "Mechanical Keyboard K5", 4, "Excellent tactile feedback, a bit loud though."),
                new Feedback("Fiona Apple", "Mechanical Keyboard K5", 5, "Best keyboard I've ever used! The RGB lighting is gorgeous."),
                new Feedback("George Lucas", "4K Monitor UltraView", 4, "Stunning display quality. Color accuracy is outstanding."),
                new Feedback("Hannah Montana", "4K Monitor UltraView", 2, "Had some dead pixels on arrival. Returned for replacement."),
                new Feedback("Ivan Petrov", "USB-C Hub Pro", 3, "Works fine but gets very hot during extended use."),
                new Feedback("Julia Roberts", "USB-C Hub Pro", 4, "Compact and versatile. All the ports I need."),
                new Feedback("Kevin Hart", "Noise Cancelling Headphones", 5, "Incredible sound quality and the noise cancellation is superb!"),
                new Feedback("Laura Palmer", "Noise Cancelling Headphones", 4, "Comfortable fit and great audio. Slightly heavy for travel."),
                new Feedback("Mike Tyson", "Webcam HD Pro", 3, "Decent video quality for the price. Auto-focus is slow."),
                new Feedback("Nancy Drew", "Webcam HD Pro", 1, "Stopped working after two weeks. Very disappointed."),
                new Feedback("Oscar Wilde", "Laptop Pro X1", 5, "A masterpiece of engineering. Worth every penny.")
            );

            feedbackRepository.saveAll(sampleFeedbacks);
            System.out.println("✅ Loaded " + sampleFeedbacks.size() + " sample feedbacks into the database.");
        } else {
            System.out.println("ℹ️ Database already contains feedback data. Skipping seed.");
        }
    }
}
